from django.apps import AppConfig


class WebsiteappConfig(AppConfig):
    name = 'WEBSITEAPP'
