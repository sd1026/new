from django.contrib import admin

from .models import AllCourses, details

# Register your models here.

admin.site.register(AllCourses)
admin.site.register(details)
