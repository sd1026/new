from django.shortcuts import render
from django.http import HttpResponse
from .models import AllCourses
from django.template import loader

# Create your views here.

def hi(request):
    ac=AllCourses.objects.all()
    template=loader.get_template('WEBSITEAPP/hi.html')
    context={
        'ac':ac
    }
    return HttpResponse(template.render(context,request))
    return render(request,'WEBSITEAPP/hi.html')

def detail(request, course_id):
    try:
        course=AllCourses.object.get(pk=course_id)
    except AllCourses.DoesNotExist:
        raise Http404('Course Not Available')
    return render(request,'WEBSITEAPP/details.html',{'course':course})